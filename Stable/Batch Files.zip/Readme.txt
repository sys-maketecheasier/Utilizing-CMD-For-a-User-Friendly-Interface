
Welcome! The Batch Files in this Zip File make challenging things or things that will take a little while to complete are suddenly made very easy. Here is a brief overview of all the batch files contained in the Zip File, and how to use them.

Activate-Deactivate any User Account
		This command will allow you to activate or deactivate any user account. You have to have Administrator Privileges, and you have to know the username for the account you want to activate/deactivate

Change Any Users Password
		This command will allow you to change the password of any user on your computer. You have to have Administrator Privileges to perform this operation, and you have to know the username of the account that you would like to change.

Create a New User Account
		This command will allow you to create a new user account on your computer. You must have administrator privileges to do this.

More Options
		This command has all options above and a few more. YOu have to know the username of the account you would like to modify/add and you also have to have Administrative Privileges.

Multiple Save2Txt
		The Save2Txt commands should explain everything you need to do. Any questions, please contact me via the website.

Text2Speech/TTS
		These commands are fairly self explanatory, you type the text and your computer will speak it.